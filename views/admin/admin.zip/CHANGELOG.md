

# Changelog


## [1.0.0] 2018-09-26
### Original Release

## [1.1.0] 2019-07-01
### Bootstrap Update, Libraries Update
- Bootstrap updated to `4.3.1`
- libraries updated to latest versions
- fixed issues

## [1.1.1] 2019-12-20
### Fixes
- Fixed navbar classes
- Fixed 'modal-' classes
- Cleaned scss files

## [1.1.2] 2020-02-04
### Fixes
- Fixed broken links
- Added Upgrade to PRO Page
- Readme updated

## [1.2.0] 2020-02-20
### Improvments
- New style for pages



